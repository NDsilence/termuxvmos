if [ ! -f /data/data/com.termux/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.termux/files/home/.termux/termux.properties ]; then
mkdir -p /data/data/com.termux/files/home/.termux
cp /data/data/com.termux/files/usr/share/examples/termux/termux.properties /data/data/com.termux/files/home/.termux/
fi
