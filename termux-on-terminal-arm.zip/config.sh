#!/system/bin/sh

[ ! -f "/tool_files/main/exbin/utils" ] && echo "! Please install lastest vmostool" && exit 1;

. /tool_files/main/exbin/utils

[ "$TOOLVERCODE" -lt 12003 ] && echo "! Please install vmostool v1.20.3+" && exit 1;
find_bb=`which busybox`
[ ! "$find_bb" ] && echo "! Please install Busybox" && exit 1;

ABI_TARGET="armeabi-v7a"

[ ! "$ABILONG" == "$ABI_TARGET" ] && echo "! This zip is for $ABI_TARGET devices" && exit;




IGNORE_PLACE=true

echo "- Termux environment for Terminal Emulator"
echo "- Created by HuskyDG"
busybox sleep 1
echo "- Remove old Termux files..."
rm -rR /tool_files/termux
echo "- Installing Termux..."
mv ./files /tool_files/termux
echo "- Creating symlinks..."
sh ./symlink.sh /tool_files/termux
echo "- Set permission for Termux"
chmod -R +x /tool_files/termux
chmod -R +x ./exbin
cp -R ./exbin/* $MDIR/exbin
echo "- You can run Termux now by call \"termux\" command"